public class SearchFailureException extends Exception{
}
